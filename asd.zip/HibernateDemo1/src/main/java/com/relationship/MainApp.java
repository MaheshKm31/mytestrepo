package com.relationship;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration config=new Configuration().configure().addAnnotatedClass(Student.class).addAnnotatedClass(Laptop.class);
		ServiceRegistry registry=new StandardServiceRegistryBuilder().applySettings(config.getProperties()).build();
		SessionFactory sf=config.buildSessionFactory(registry);
		Session session=sf.openSession();
		session.beginTransaction();
		Laptop lap=new Laptop();
		lap.setLid(101);
		lap.setLname("HP");
		Laptop lap1=new Laptop();
		lap1.setLid(101);
		lap1.setLname("HP");
		Student s=new Student();
		s.setRollno(1001);
		s.setName("Jit");
		s.setMarks(97);
		//one to one relationship
		//s.setLaptop(lap);
		
		//one to many bidirectional relationship
		/*
		 * s.getLaptop().add(lap);
		 *  s.getLaptop().add(lap1); 
		 *  lap.setStud(s);
		 *  lap1.setStud(s);
		 */
        
		//many to many relationship
		lap.getStud().add(s);
		lap1.getStud().add(s);
		s.getLaptop().add(lap); 
		s.getLaptop().add(lap1);

		session.save(lap);
		session.save(lap1);
		session.save(s);
		session.getTransaction().commit();
	}

}
