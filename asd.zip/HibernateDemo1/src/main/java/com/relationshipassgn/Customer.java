package com.relationshipassgn;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Customer {
	@Id
	private int custId;
	private String custName;
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	@OneToMany(mappedBy = "cust")private List<Transactions> transaction =new ArrayList<Transactions>();
	public List<Transactions> getTransaction1(){return transaction;}
	public void setTransaction(List<Transactions> transaction) {this.transaction=transaction;}
}