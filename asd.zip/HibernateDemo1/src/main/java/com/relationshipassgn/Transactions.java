package com.relationshipassgn;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Transactions {
	@Id
	private int transId;
	private int transAmt;
	private String transType;
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public int getTransAmt() {
		return transAmt;
	}
	public void setTransAmt(int transAmt) {
		this.transAmt = transAmt;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	@ManyToOne private Customer cust;
	public Customer getCust() {return cust;}
	public void setCustomer(Customer cust) { this.cust = cust; }

}