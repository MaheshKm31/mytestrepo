package com.relationshipassgn;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class MainApp {
	public static void main(String[] args) {
		Configuration config=new Configuration().configure().addAnnotatedClass(Customer.class).addAnnotatedClass(Transactions.class);
		ServiceRegistry registry=new StandardServiceRegistryBuilder().applySettings(config.getProperties()).build();
		SessionFactory sf=config.buildSessionFactory(registry);
		Session session=sf.openSession();
		session.beginTransaction();
		
		Transactions t=new Transactions();
		t.setTransId(101);
		t.setTransAmt(50000);
		t.setTransType("debit");
		
		Transactions t1=new Transactions();
		t1.setTransId(102);
		t1.setTransAmt(60000);
		t1.setTransType("credit");
		
		Customer c=new Customer();
		c.setCustId(1001);
		c.setCustName("vikash");
		
		c.getTransaction1().add(t);
		c.getTransaction1().add(t1);
		t.setCustomer(c);
		t1.setCustomer(c);
		
		session.save(t);
		session.save(t1);
		session.save(c);

		session.getTransaction().commit();
	}
}